﻿using Link_Bridge_Application.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Net.Http;
namespace Link_Bridge_Application.Controllers
{
    public class InventoryController : Controller
    {
        // GET: Inventory
        public ActionResult Index()
        {
            IEnumerable<ProductModel> prodList;
            HttpResponseMessage response = GlobalVariables.WebApiClient.GetAsync("Products1").Result;
            prodList = response.Content.ReadAsAsync<IEnumerable<ProductModel>>().Result;
            return View(prodList);
        }
    }
}